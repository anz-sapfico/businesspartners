sap.ui.define([
	"ns/businesspartners/test/unit/controller/Suppliers.controller"
], function () {
	"use strict";
});
